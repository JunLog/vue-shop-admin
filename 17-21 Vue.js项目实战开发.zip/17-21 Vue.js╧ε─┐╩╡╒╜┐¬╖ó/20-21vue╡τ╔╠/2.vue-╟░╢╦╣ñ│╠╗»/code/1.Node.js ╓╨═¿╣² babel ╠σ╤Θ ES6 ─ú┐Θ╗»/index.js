// import m1, { s1, s2 as ss2, say } from './m1.js'

// console.log(m1)
// console.log(s1)
// console.log(ss2)
// console.log(say)


import './m2.js'